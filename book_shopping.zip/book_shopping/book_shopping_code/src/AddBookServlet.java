import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class AddBookServlet extends HttpServlet
{
 public void doGet(HttpServletRequest req,HttpServletResponse res)
 throws IOException,ServletException
 {
  res.setContentType("text/html");
  PrintWriter pw=res.getWriter();
  /*pw.println("<html>"+
"<heaD>"+
"<title>"+
      "Galaxie online Book Store:Registration Form"+
"</title>"+
"<script language='JavaScript'>"+
"function val(){"+
  "for(var i=0;i<1;i++){"+
"if(window.document.f1.uname.value==null||window.document.f1.uname.value==\"\"){"+
  "window.alert('Name cannot be empty');"+
  "window.document.f1.uname.focus();"+
  +"}"+
"}"+
  "}"+
"</script>"+
"</head>"+
"<body background='c:/onlinebs/back.gif'>"+
"<centeR><b><u>  Please fill all the fields </u></b></centeR>"+

" <a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'></a>"+
"<center><form name='f1' method='GET' action='"+res.encodeUrl("http://localhost:8080/examples/servlet/signup")+"'>"+
   "<table>"+
      "<tr>"+
        "<td>Name</td>"+
        "<td><input type='text' name='uname'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>User Id</td>"+
        "<td><input type='text' name='uid'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>Password</td>"+
        "<td><input type='password' name='pwd'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>Confirm Password</td>"+
        "<td><input type='password' name='cpwd'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>Address</td>"+
        "<td><input name='address'></td>"+
      "</tr> "+
      "<tr>"+
        "<td>E-mail Address</td>"+
        "<td><input type='text' name='email'></td>"+
      "</tr></table><br><br>"+
"<input type='submit' value='Submit'>"+
"</center>"+
        
"</form></centeR>"+
"</body></html>");*/

  pw.println("<html>"+
"<heaD>"+
"<title>"+
      "EBOOKZ:ADD BOOK Form"+
"</title>"+
"<script language='JavaScript'>"+
"</script>"+
"</head>"+
"<body background='c:/onlinebs/back.gif'>"+
"<centeR><b><u>  Please fill all the fields </u></b></centeR>"+

" <a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'>[SignOut]</a>"+
"<center><form method='GET' action='"+res.encodeUrl("http://localhost:8080/examples/servlet/Admin")+"'>"+
   "<table>"+
      "<tr>"+
        "<td>Sur-Name</td>"+
        "<td><input type='text' name='surname'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>First-Name</td>"+
        "<td><input type='text' name='firstname'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>Book-Title</td>"+
        "<td><input type='text' name='booktitle'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>Price</td>"+
        "<td><input name='price'></td>"+
      "</tr> "+
	"<tr>"+
        "<td>Year</td>"+
        "<td><input name='year'></td>"+
      "</tr> "+
      "<tr>"+
        "<td>Description</td>"+
        "<td><input type='text' name='description'></td>"+
      "</tr></table><br><br>"+
"<input type='submit' value='Submit'>"+
"</center>"+
        
"</form></centeR>"+
"</body></html>");
  
 }
}
