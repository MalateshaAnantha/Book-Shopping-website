	public class BookDBServlet  {

    private BookstoreDB books;
	public BookDBServlet(){
	books=new BookstoreDB();
	}

    public BookDetails getBookDetails(String bookId) {
        return books.getBookDetails(bookId);
    }

    public BookDetails[] getBooksSortedByTitle() {
        return books.getBooksSortedByTitle();
    }

    public int getNumberOfBooks() {
        return books.getNumberOfBooks();
    }
}
