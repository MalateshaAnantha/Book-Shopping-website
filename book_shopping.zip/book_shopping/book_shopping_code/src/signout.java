import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class signout extends HttpServlet
{
 public void doGet(HttpServletRequest req,HttpServletResponse res)
 throws IOException,ServletException
 {
  res.setContentType("text/html");
  HttpSession session=req.getSession(true);
  session.invalidate();
  res.sendRedirect(res.encodeUrl("http://localhost:8080/examples/servlet/home"));
 }
}
