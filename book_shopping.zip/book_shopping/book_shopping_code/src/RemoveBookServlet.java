import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class  RemoveBookServlet extends HttpServlet
{
	Connection con;
	public void init(ServletConfig sc)
	{
		try
		{
			super.init(sc);
		           Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		           con=DriverManager.getConnection("Jdbc:Odbc:books","scott","tiger");
			   }catch(Exception e){
				    System.out.println("Exception in Remove Book Servlet :"+e);
			}
	}

	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
				PreparedStatement pst;
			    ResultSet rs;
				PrintWriter pw;

				try
				{
					pw=res.getWriter();
					String bookid=req.getParameter("bookid");
					String query="delete from books where bookid=?";
					pst = con.prepareStatement(query);
				    pst.setString(1,bookid);
			       int i = pst.executeUpdate();  
				   pw.println("<html><heaD><title>EBOOKZ Online Book store</title></head>"+
"<body background='c:/onlinebs/back.gif'>");
				   pw.println(" <a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'>[SignOut]</a>");
				    //st1=con.createStatement();
					if(i==1)
					{
						pw.println("<h3 align=center>Book Removed from Store</h3>");
						pw.println("<a href=\"" +  res.encodeUrl("http://localhost:8080/examples/servlet/home\">")+"<h1 align=center>Login</h1></a><BR> ");
					}

			/*
					ShoppingCartItem item = (ShoppingCartItem) e.nextElement();
	                BookDetails bookDetails = (BookDetails) item.getItem();
					pw.println("<html><title>Galaxie Online BookStore</title><body background='c:/onlinebs/back.gif'>");
					pw.println("<tr>" +"<td align=\"right\" bgcolor=\"#ffffff\">" +
                            item.getQuantity() +"</td>" +"<td bgcolor=\"#ffffaa\">" +                          "<strong><a href=\"" +                           response.encodeUrl("http://localhost:8080/examples/servlet/BookDetailServlet?bookId=" +bookDetails.getBookId()) +
                            "\">" + bookDetails.getTitle() + "</a></strong>" +"</td>" +
                            "<td bgcolor=\"#ffffaa\" align=\"right\">" +                         Cashier.format(bookDetails.getPrice()) +"</td>" +
                            "<td bgcolor=\"#ffffaa\">" +"<strong>" + "<a href=\"" );				*/
							pw.println("</body></html>");

					}
				catch(Exception e)
				{
					System.out.println("Exception in Remove Book Servelt  No.1 :"+e.toString());
				}
	}
}