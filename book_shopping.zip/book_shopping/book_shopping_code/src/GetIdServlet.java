//package database;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
//import java.io.IOException;
import java.io.*;

public class GetIdServlet extends HttpServlet{
	Connection con;

    
    public void init (ServletConfig sc) {
           try{
				   super.init(sc);
		           Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		           con=DriverManager.getConnection("Jdbc:Odbc:books","scott","tiger");
			   }catch(Exception e){
				    System.out.println("Exception in GetIdServlet :"+e);
			}
    }
	
	   public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
		{
			    Statement st;
				Statement st1;
			    ResultSet rs;
				ResultSet rs1;
				PrintWriter pw;
				int count=0;
    
	    try
			{
					pw=res.getWriter();
					String bookid="";
					String title="";
					String name="";
					
			        st=con.createStatement();
				    st1=con.createStatement();
		            rs=st.executeQuery("select bookid,booktitle,firstname from books"); 
					rs1=st1.executeQuery("select bookid,booktitle,firstname from books"); 
					pw.println("<html><heaD><title>EBOOKZ Online Book store</title></head>"+
"<body background='c:/onlinebs/back.gif'>");
					pw.println(" <a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'>[SignOut]</a>");
					if(rs1!=null)
						{
						while(rs1.next())
							{
						count++;
						}
					
					}
					System.out.println(""+count);
		            if(rs!=null ){
						if(count>0){
						 pw.println("<br> &nbsp;" +
                     
                    "<center> <table><caption><h3>Please choose from list of books you want to remove </h3></caption>");

	
					while(rs.next())
		            {
			              bookid=rs.getString(1);
						  title=rs.getString(2);
						  name=rs.getString(3);

						  pw.println("<tr>" +"<td bgcolor=\"#ffffaa\">" +bookid+"</td><td bgcolor=\"#ffffaa\">" +title+"</td><td bgcolor=\"#ffffaa\">" +name+"</td><td bgcolor=\"#ffffaa\">" +"<a href=\"" +                       res.encodeUrl("http://localhost:8080/examples/servlet/RemoveBookServlet?bookid=" +bookid+"\"")+" >Remove Book</a> </td></tr>");
						 //System.out.println(""+s+rs.getString(2)+rs.getString(3)+rs.getString(4)+Float.parseFloat(rs.getString(5))+Integer.parseInt(rs.getString(6))+rs.getString(7));              
					 }
					  pw.println("</table></center>");
					}else{
						System.out.println("I AM HERE "+count);
						pw.println("<h3 align=center>Store is Empty</h3>");
						//pw.println(" <a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'>[SignOut]</a>");
					}
					}
		 		   			 
					/*pw.println("<a href='http://localhost:8080/examples/servlet/RemoveBookServlet'>Remove</a> <br><br>");
					pw.println("<a href='http://localhost:8080/examples/servlet/RemoveBookServlet'>GetDetails</a> ");

//		    		pw.println("<input type='submit' value='remove'>"); */
					pw.println("</body></html>");
           }
		   catch(Exception e)
			   {
						System.out.println("Exception in GetIdServlet :"+e);
			}
    }    
}