import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class login extends HttpServlet
{
  Connection con;
  Statement st;
  ResultSet rs;
  PrintWriter pw;
  HttpSession session; 
  public void init(ServletConfig config)
  {
   try
     {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
      con=DriverManager.getConnection("Jdbc:Odbc:books","scott","tiger");
      st=con.createStatement();
     }catch(Exception e){System.out.println(" "+e);} 
  } 
  public void doGet(HttpServletRequest req,HttpServletResponse res)
  throws IOException,ServletException 
  {
   session=req.getSession(true);
   res.setContentType("text/html"); 
   String error=req.getParameter("error");
    
   try{
     pw=res.getWriter();
     if(error!=null)
      pw.println("Invalid Password or UserID<a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'>Back</a>");
     rs=st.executeQuery("select * from login");     
     String userid=req.getParameter("user");
     String pwd=req.getParameter("pwd");
     boolean f=true;
     while(rs.next())
     {
      String userid1=rs.getString(1);
      String pwd1=rs.getString(2);
       if((userid.equals(userid1)) && (pwd.equals(pwd1)))
       {
        session.putValue("name",userid1);
       if((userid.equals("admin"))&&(pwd.equals("admin")))
		   {
		   System.out.println("HE IS LOGGING AS AN ADMIN");
			//res.sendRedirect(res.encodeUrl("http://localhost:8080/examples/servlet/Update"));
		  //res.sendRedirect(res.encodeUrl("http://localhost:8080/examples/servlet/AddBookServlet"));
		  res.sendRedirect(res.encodeUrl("http://localhost:8080/examples/updateBook.html"));

	   }else{
		   res.sendRedirect(res.encodeUrl("http://localhost:8080/examples/servlet/BookStoreServlet"));
	   }
       }  
       else
        {
         f=false;
         }
/*		 if(userid.equals("admin")&&(pwd.equals("admin")))
		 {//
			 session.putValue("name",userid1);
        res.sendRedirect(res.encodeUrl("http://localhost:8080/examples/servlet/Admin"));
       }  
       else
        {
         f=false;
         }*/
      } 
      if(f==false)
       res.sendRedirect(res.encodeUrl("http://localhost:8080/examples/servlet/home"));
     }catch(Exception e){System.out.println(" "+e);}
  }  
}