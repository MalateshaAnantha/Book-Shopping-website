// package cart;

import java.io.*;
import java.util.*;
import java.text.*;
//import database.BookDetails;


public class Cashier {

    private static final double SalesTaxRate = 0.0825;

    ShoppingCart cart;

    public Cashier(ShoppingCart cart) {
        this.cart = cart;
    }

    public double getAmount() {
        double amount = 0.0;

        for(Enumeration e = cart.getItems(); e.hasMoreElements(); ) {
            ShoppingCartItem item = (ShoppingCartItem) e.nextElement();
            BookDetails bookDetails = (BookDetails) item.getItem();

            amount += item.getQuantity() * bookDetails.getPrice();
        }
        return roundOff(amount);
    }

    public double getTax() {
        return roundOff(getAmount() * SalesTaxRate);
    }

    public double getTotal() {
        return roundOff(getAmount() + getTax());
    }

    private double roundOff(double x) {
        long val = Math.round(x*100); // cents
        return val/100.0;
    }

    public static String format(double d) {
        NumberFormat nf = NumberFormat.getCurrencyInstance();
        return nf.format(d);
    }
}

