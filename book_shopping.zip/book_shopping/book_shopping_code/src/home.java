import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class home extends HttpServlet
{
 public void doGet(HttpServletRequest req,HttpServletResponse res)
 throws IOException,ServletException
 {
  res.setContentType("text/html");
  PrintWriter pw=res.getWriter();
  pw.println("<html><heaD><title>EBOOKZ Online Book store</title></head>"+
"<body background='c:/onlinebs/back.gif'>"+
 "<center><h3 style='color:red'>EBOOKZ Online Bookstore</h3><hr></centeR>"+
 "<form method='GET' action='"+res.encodeUrl("http://localhost:8080/examples/servlet/login")+"'>"+
   "<table align='center'>"+
      "<tr>"+
       "<td>User Id</td>"+
       "<td><input type='text' name='user'></td>"+
      "</tr>"+
      "<tr>"+
       "<td>Password</td>"+
       "<td><input type='password' name='pwd'></td>"+
      "</tr>"+
      "<tr>"+
      "</tr>"+
      "<tr>"+
      "</tr>"+
       "<tr><td></td><td><input type='submit' value='Login'></td></tr></table>"+
"<br><br>"+
"<centeR>If you are not member <a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/registration")+"'>Sign Up</a></centeR>"+
"<centeR>Administrator : UseAdministrator Login</centeR>"+
    "</table>"+
  "</form>"+
"</body></html>");
 }
}