import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

//import database.*;
//import cart.ShoppingCart;

public class CatalogServlet extends HttpServlet  
{ 
	public void init(ServletConfig sc)
	{
		try{
		super.init(sc);}
		catch(Exception e)
		{
		}
	}
    public void doGet (HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
        // Get the user's session and shopping cart
	HttpSession session = request.getSession(true);
	System.out.println("session created");
	ShoppingCart cart = (ShoppingCart)session.getValue(session.getId());
		//System.out.println("session created"+cart);
        // If the user has no cart, create a new one
        if (cart == null) {
            cart = new ShoppingCart();
            session.putValue(session.getId(), cart);
        }

	System.out.println("session created"+cart);
	// set content-type header before accessing the Writer
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

	// then write the data of the response
        out.println("<html><head><title> Book Catalog </title></head>");
	out.println("<body  background='c:/onlinebs/back.gif'>");
	out.println("<a href='"+response.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'></a>"+"["+session.getValue("name")+"]<a href='"+response.encodeUrl("http://localhost:8080/examples/servlet/signout")+"'>[Sign Out]</a>");
	out.println("<center><hr>&nbsp;<h1><font size=\"+3\" color=\"red\">EBOOKZ Online </font>");
	out.println("<font size=\"+3\" color=\"purple\">Bookstore</font></h1></center><br>&nbsp;<hr>&nbsp;");

        //Data on the books are from the database servlet
		/*ServletConfig sc=getServletConfig();
		System.out.println(""+sc);
		ServletContext sc1=sc.getServletContext();
		System.out.println(""+sc1);*/
/*        BookDBServlet database = (BookDBServlet)
            getServletConfig().getServletContext().getServlet("BookDBServlet");
//System.out.println(""+database);*/
BookDBServlet database = (BookDBServlet)new BookDBServlet();
        // Additions to the shopping cart
        String bookToAdd = request.getParameter("Buy");
        if (bookToAdd != null) {
            BookDetails book = database.getBookDetails(bookToAdd);

            cart.add(bookToAdd, book);
            out.println("<p><h3>" +
                        "<font color=\"#ff0000\">" +
                        "You just added <i>" + book.getTitle() + "</i> "+
                        "to your shopping cart</font></h3>");
        }

        //Give the option of checking cart or checking out if cart not empty
        if (cart.getNumberOfItems() > 0) {
            out.println("<table><tr>" +"<th align=\"left\"><a href=\" " +
           response.encodeUrl("http://localhost:8080/examples/servlet/ShowCartServlet") +
                        "\"> Check Shopping Cart</a></th>" +"<th>&nbsp;</th>" +
                        "<th align=\"right\"><a href=\"" +                        response.encodeUrl("http://localhost:8080/examples/servlet/CashierServlet") +
                        "\"> Buy your Books</a></th>" +
                        "</tr></table");
        }

        // Always prompt the user to buy more -- get and show the catalog
        out.println("<br> &nbsp;" +
                    "<h3>Please choose from our selections</h3>" +
                    "<center> <table>");

        BookDetails[] books = database.getBooksSortedByTitle();
        int numBooks = database.getNumberOfBooks();
        for(int i=0; i < numBooks; i++) {
            String bookId = books[i].getBookId();

            //Print out info on each book in its own two rows
            out.println("<tr>" +

                        "<td bgcolor=\"#ffffaa\">" +
                        "<a href=\"" +
                        response.encodeUrl("http://localhost:8080/examples/servlet/BookDetailServlet?bookId=" +
                                           bookId) +
                        "\"> <strong>" + books[i].getTitle() +
                        "&nbsp; </strong></a></td>" +

                        "<td bgcolor=\"#ffffaa\" rowspan=2>" +
                        "$" + books[i].getPrice() +
                        "&nbsp; </td>" +

                        "<td bgcolor=\"#ffffaa\" rowspan=2>" +
                        "<a href=\"" +
                        response.encodeUrl("http://localhost:8080/examples/servlet/CatalogServlet?Buy=" + bookId)
                        + "\"> &nbsp; Add to Cart &nbsp;</a></td></tr>" +

                        "<tr>" +
                        "<td bgcolor=\"#ffffff\">" +
                        "&nbsp; &nbsp; by <em> " + books[i].getFirstName() +
                        " " + books[i].getSurname() + "</em></td></tr>");
        }

        out.println("</table></center></body></html>");
        out.close();
    }

    public String getServletInfo() {
        return "The Catalog servlet adds books to the user's " +
               "shopping cart and prints the catalog.";

    }
}
