import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class Admin extends HttpServlet
{
 Connection con;
 PreparedStatement pst,pst1; 
 PrintWriter pw;
 boolean flag=false;
 public void init(ServletConfig config)
 {
  try
  {
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("Jdbc:Odbc:books","scott","tiger");

  }catch(Exception e){System.out.println(" "+e);} 
 }
 public void doGet(HttpServletRequest req,HttpServletResponse res)
 throws IOException,ServletException
 {
   try
   {
    res.setContentType("text/html");
    pw=res.getWriter();
	pw.println("<html><heaD><title>EBOOKZ</title></head>"+
"<body background='c:/onlinebs/back.gif'>"+
 "<center><h3 style='color:red'>");
	String oldId="";
	String bid="";
	int id=0;
	/*Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select  * from ebookz");
if(rs!=null && rs.next())
	oldId=(String)rs.getString(1);

rs.close();
if(oldId !=null && !(oldId.equals("")))
	{
	String comp=oldId.substring(oldId.indexOf("B")+1,oldId.lastIndexOf("ookz"));
	
id=Integer.parseInt(comp)+1;
 bid="E2004B"+id+"ookz";
st.executeUpdate("update ebookz set bid='"+bid+"' where bid='"+oldId+"'");

}*/

String surname=req.getParameter("surname");
String firstname=req.getParameter("firstname");
String title=req.getParameter("booktitle");
String price=req.getParameter("price");
String year=req.getParameter("year");
String desc=req.getParameter("description");

      
 //pst1=con.prepareStatement("insert into login values(?,?)");  
 pst=con.prepareStatement("insert into books values(?,?,?,?,?,?,?)");  
// System.out.println(" a"+surname+"b "+firstname+"c"+title+"d"+price+"e"+"f"+year+"g"+desc);
 if(!(surname.equals(null)) && !(surname.equals("")) && !(firstname.equals(null)) && !(firstname.equals("")) && !(title.equals(null)) && !(title.equals("")) && !(price.equals(null)) && !(price.equals("")) && !(year .equals(null)) && !(year .equals("")) && !(desc.equals(null))&& !(desc.equals(""))){ 
	 System.out.println(" a"+surname+"b "+firstname+"c"+title+"d"+price+"e"+"f"+year+"g"+desc+"I AM HERE");
 
   /* pst.setString(1,bid);
    pst.setString(2,req.getParameter("surname"));
    pst.setString(3,req.getParameter("firstname"));
    pst.setString(4,req.getParameter("booktitle"));
	pst.setString(5,req.getParameter("price"));
    pst.setString(6,req.getParameter("year"));
	pst.setString(7,req.getParameter("description"));*/
	Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select  * from ebookz");
if(rs!=null && rs.next())
	oldId=(String)rs.getString(1);

rs.close();
if(oldId !=null && !(oldId.equals("")))
	{
	System.out.println(""+oldId);
	String comp=oldId.substring(oldId.indexOf("B")+1,oldId.lastIndexOf("ookz"));
	System.out.println(""+comp);
id=Integer.parseInt(comp)+1;
 bid="E2004B"+id+"ookz";
 System.out.println(""+bid);
st.executeUpdate("update ebookz set bid='"+bid+"' where bid='"+oldId+"'");

}
 System.out.println(" a"+surname+"b "+firstname+"c"+title+"d"+price+"e"+"f"+year+"g"+desc+"I AM HERE 1");
	
	pst.setString(1,bid);
    pst.setString(2,surname);
    pst.setString(3,firstname);
    pst.setString(4,title);
	pst.setString(5,price);
    pst.setString(6,year);
	pst.setString(7,desc);
     
    int j=pst.executeUpdate();  
	//pw.println(" I AM HERE"+j);
//     System.out.println("Ashok");
    //int i=pst1.executeUpdate();
    if( j==1){

     pw.println("<a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'></a>"+
     "Store updated  Successfully<br><br><a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'>Login</a>");
    }else  {
		pw.println("There is some error when you are Enetring Data Please Check<br><a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/AddBookServlet")+"'>Back</a>"); 
		}
 
 }else{
 pw.println("There is some error when you are Enetring Data Please Check<br><a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/AddBookServlet")+"'>Back</a>");
 
 }
  }catch(Exception e)
   {
    System.out.println(" "+e);
    pw.println("There is some error when you are regestering pleasse check <br><a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/AddBookServlet")+"'>Back</a>"); 
   }    
 } 
}
