//package database;
import java.util.*;
import java.sql.*;


class BookstoreDB 
{

    private Hashtable database;
    private BookDetails[] dbByTitle;
    Connection con;
    Statement st,st1;
    ResultSet rs,rs1; 
    int count=0;
    BookstoreDB () {
           try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("Jdbc:Odbc:books","scott","tiger");
            st=con.createStatement();
            st1=con.createStatement();
            rs=st.executeQuery("select * from books"); 
            rs1=st1.executeQuery("select * from books");
            while(rs1.next())
            {
             count++;    
            } 
            System.out.println("Count: "+count);
            BookDetails book;
            database = new Hashtable();
            dbByTitle = new BookDetails[count]; 
            int acount=0;
            while(rs.next())
             {
              String s=rs.getString(1);
			  //System.out.println(""+s+rs.getString(2)+rs.getString(3)+rs.getString(4)+Float.parseFloat(rs.getString(5))+Integer.parseInt(rs.getString(6))+rs.getString(7));
              book = new BookDetails(s,rs.getString(2),rs.getString(3),rs.getString(4),Float.parseFloat(rs.getString(5)),Integer.parseInt(rs.getString(6)),rs.getString(7));
			  System.out.println(""+book);
             // database.put(new Integer(s), book);
				database.put(s, book);
              dbByTitle[acount]=book;
              acount++;
             }
           }catch(Exception e){System.out.println("Exception in BookstoreDB :"+e);}

    }

    BookDetails getBookDetails(String bookId) {
       // Integer key = new Integer(bookId);
		String key=new String(bookId);
        return (BookDetails)database.get(key);
    }

    BookDetails[] getBooksSortedByTitle() {
        return dbByTitle;
    }

    int getNumberOfBooks() {
        return count;
    }
}