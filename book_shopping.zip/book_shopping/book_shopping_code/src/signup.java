import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class signup extends HttpServlet
{
 Connection con;
 PreparedStatement pst,pst1,pst2; 
 PrintWriter pw;
 public void init(ServletConfig config)
 {
  try
  {
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   con=DriverManager.getConnection("Jdbc:Odbc:books","scott","tiger");

  }catch(Exception e){System.out.println(" "+e);} 
 }
 public void doGet(HttpServletRequest req,HttpServletResponse res)
 throws IOException,ServletException
 {
   try
   {
    res.setContentType("text/html");
	    pw=res.getWriter();
		pw.println("<html>"+
"<heaD>"+
"<title>"+
      "EBOOKZ online Book Store:WelCome"+
"</title>"+
"<script language='JavaScript'>"+
"</script>"+
"</head>"+
"<body background='c:/onlinebs/back.gif'>");
		Statement st=con.createStatement();
	ResultSet rs=st.executeQuery("select  UserId from login where UserId='"+req.getParameter("uid")+"'");
	if(rs !=null && rs.next()){
	 pw.println("The userid Already Exists please choose some other ID<br><a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/registration")+"'>Back</a>");
	}else{
    pst=con.prepareStatement("insert into userinfo values(?,?,?,?)");  
    pst1=con.prepareStatement("insert into login values(?,?)");  
	pst2=con.prepareStatement("insert into creditcardinfo values(?,?)");

    pst.setString(1,req.getParameter("uname"));
    pst.setString(2,req.getParameter("uid"));
    pst.setString(3,req.getParameter("address"));
    pst.setString(4,req.getParameter("email"));

    pst1.setString(1,req.getParameter("uid"));
    pst1.setString(2,req.getParameter("pwd"));

    pst2.setString(1,req.getParameter("cct"));
    pst2.setString(2,req.getParameter("ccno"));
     
    int j=pst.executeUpdate();  
//     System.out.println("Ashok");
    int i=pst1.executeUpdate();
	int k=pst2.executeUpdate();
    if(i==1 && j==1 && k==1)
     pw.println("<a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'></a>"+
     "You are successfully Registered<br><br><a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'>Login</a>");
    else
     pw.println("There is some error when you are regestering please check<br><a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/registration")+"'>Back</a>");
	}
  }catch(Exception e)
   {
    System.out.println(" "+e);
    pw.println("There is some error when you are regestering pleasse check"); 
   } 
  
 } 
}
