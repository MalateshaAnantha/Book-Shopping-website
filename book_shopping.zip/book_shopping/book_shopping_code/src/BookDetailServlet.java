import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
//import database.*;
//import cart.ShoppingCart;

public class BookDetailServlet extends HttpServlet 
{
    public void doGet (HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
        // Get the user's session and shopping cart
        HttpSession session = request.getSession(true);
        ShoppingCart cart =(ShoppingCart)session.getValue(session.getId());
        
        // If the user has no cart, create a new one
        if (cart == null) 
        {
            cart = new ShoppingCart();
            session.putValue(session.getId(), cart);
        }

	// set content-type header before accessing the Writer
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

	// then write the response
        out.println("<html>" +"<head><title>Book Description</title></head>" +
                    "<body  background='c:/onlinebs/back.gif'>" +
                    "<a href='"+response.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'></a>"+ 
                    "["+session.getValue("name")+"]<a href='"+response.encodeUrl("http://localhost:8080/examples/servlet/signout")+"'>[Sign out]</a><center>" +
                    "<hr> <br> &nbsp;" +
                    "<h1>" +
                    "<font size=\"+3\" color=\"red\">EBOOKZ</font>" +
                    "<font size=\"+3\" color=\"purple\">Bookstore</font>" +
                    "</h1>" +
                    "</center>" +
                    "<br> &nbsp; <hr> <br> &nbsp;");

        //Get the identifier of the book to display
        String bookId = request.getParameter("bookId");
        if (bookId != null) 
        {
            // and the information about the book
            /*BookDBServlet database = (BookDBServlet)
            getServletConfig().getServletContext().getServlet("BookDBServlet");*/
			BookDBServlet database = new BookDBServlet();
            BookDetails bd = database.getBookDetails(bookId);

            //Print out the information obtained
            out.println("<h2>" + bd.getTitle() + "</h2>" +
                        "&nbsp; By <em>" + bd.getFirstName() + ", " +
                        bd.getSurname() + "</em> &nbsp; &nbsp; " +
                        "(" + bd.getYear() + ")<br> &nbsp; <br>" +
                        "<h4>Here's what the critics say: </h4>" +
                        "<blockquote>" + bd.getDescription() +
                        "</blockquote>" +
                        "<h4>Our price: $" + bd.getPrice() + "</h4>" +
                        "<center>" +
                        "<p><a href=\"" +
                        response.encodeUrl("http://localhost:8080/examples/servlet/CatalogServlet?Buy=" + bookId) +
                        "\"> Add this item to your shopping cart.</a></p>" +
                        "</center>");
        }
        out.println("</body></html>");
        out.close();
    }

    public String getServletInfo() 
    {
        return "The BookDetail servlet returns information about" +
               "any book that is available from the bookstore.";
    }
}
