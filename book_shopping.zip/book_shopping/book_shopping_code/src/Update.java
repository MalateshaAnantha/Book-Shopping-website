import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class Update extends HttpServlet
{
 public void doGet(HttpServletRequest req,HttpServletResponse res)
 throws IOException,ServletException
 {
  res.setContentType("text/html");
  PrintWriter pw=res.getWriter();
  pw.println("<html>"+
"<heaD>"+
"<title>"+
      "EBOOKZ online Book Store:Updating Stores"+
"</title>"+
"<script language='JavaScript'>"+
"</script>"+
"</head>"+
"<body background='c:/onlinebs/back.gif'>"+
"<centeR><b><u>  Please fill all the fields </u></b></centeR>"+

" <a href='"+res.encodeUrl("http://localhost:8080/examples/servlet/home")+"'><img src='c:/onlinebs/home.gif'></a>"+
"<center><form method='GET' action='"+res.encodeUrl("http://localhost:8080/examples/servlet/Admin")+"'>"+
   "<table>"+
      "<tr>"+
        "<td>BookId</td>"+
        "<td><input type='text' name='bookid'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>SurName</td>"+
        "<td><input type='text' name='surname'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>FirstName</td>"+
        "<td><input type='text' name='firstname'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>BookTitle</td>"+
        "<td><input type='text' name='booktitle'></td>"+
      "</tr>"+
      "<tr>"+
        "<td>Price</td>"+
        "<td><input type='text name='price'></td>"+
      "</tr> "+
      "<tr>"+
        "<td>Year of print</td>"+
        "<td><input type='text' name='year'></td>"+
      "</tr>"+
		"<tr>"+
        "<td>Description</td>"+
        "<td><input type='text' name='description'></td>"+
      "</tr></table><br><br>"+
"<input type='submit' value='Submit'>"+
"</center>"+
        
"</form></centeR>"+
"</body></html>");
  
 }
}
