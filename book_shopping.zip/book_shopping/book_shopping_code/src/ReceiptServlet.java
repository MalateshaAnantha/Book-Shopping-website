import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;

public class ReceiptServlet extends HttpServlet 
{ 
    Connection con;
    Statement st;
    ResultSet rs;     
    PreparedStatement pst;
    String userid=""; 
    ShoppingCart cart; 
     String booksinfo="";
    public void init(ServletConfig config)
    {
     try
       {
        super.init(config);
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        con=DriverManager.getConnection("Jdbc:Odbc:books","scott","tiger");
        st=con.createStatement();
        pst=con.prepareStatement("insert into purchageinfo values(?,?,?,?,?)");
       }catch(Exception e){System.out.println(" "+e);} 
    }
    public void doPost(HttpServletRequest request,HttpServletResponse response) 
      throws ServletException, IOException
    {
        // Get the user's session and shopping cart
        HttpSession session = request.getSession(true);
        ShoppingCart cart =
            (ShoppingCart)session.getValue(session.getId());
        
        // If the user has no cart, create a new one
        if (cart == null) {
            cart = new ShoppingCart();
            session.putValue(session.getId(), cart);
        }
        
        // Payment received -- invalidate the session

         userid=session.getValue("name").toString(); 
 
        cart=(ShoppingCart)session.getValue(session.getId());
        Cashier cash=new Cashier(cart);

        session.invalidate();
        Enumeration enu=cart.getItems();
        
        while(enu.hasMoreElements())
          {
            ShoppingCartItem item=(ShoppingCartItem)enu.nextElement();
            BookDetails bookDetails = (BookDetails) item.getItem();
            int qu=item.getQuantity();
           booksinfo=booksinfo+" \""+bookDetails.getBookId()+" "+bookDetails.getTitle()+" "+qu+"\"";
         }    
        // set content type header before accessing the Writer
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // then write the response
        out.println("<html>" +
                    "<head><title> Receipt </title>" +
                    "<meta http-equiv=\"refresh\" content=\"4; url=" +
                    response.encodeUrl("http://localhost:8080/examples/servlet/home")+";\">" +
                    "</head>" +
                    
                    "<body background='c:/onlinebs/back.gif'>" +
                    "["+userid+"]"+
                   "<center>" +
                    "<hr>  &nbsp;" +
                    "<h1>" +
                    "<font size=\"+3\" color=\"red\">EBOOKZ Online </font>" +
                    "<font size=\"+3\" color=\"purple\">Bookstore</font>" +
                    "</h1>" +
                    "</center>" +
                    "<br> &nbsp; <hr>  &nbsp;");
        
            boolean flag=false;      
            try{
             rs=st.executeQuery("select * from creditcardinfo");
             
            while(rs.next())
            {
             String cardname=rs.getString(1);
             String cardno=rs.getString(2); 
             if(cardname.equals(request.getParameter("cardname")) && cardno.equals(request.getParameter("cardnum")))
              {
               flag=true;
               pst.setString(1,userid);
               pst.setString(2,cardname);
               pst.setString(3,cardno);
               pst.setDouble(4,cash.getTotal());
               pst.setString(5,booksinfo); 
               pst.executeUpdate();
               break;
              }  
            }
           }
         catch(Exception e)
           {
            System.out.println(" "+e);
            out.println("The information provided by is not sufficiant");
           }
          if(flag==true)
             {
              out.println("<h3>Thank you for purchasing your books from us " +
                    request.getParameter("cardname") +
                    "<p>Please shop with us again soon!</h3>" +
                    
                    "<p><i>This page automatically resets.</i>" +

                    "</body></html>");
              }
           else
            {
                   out.println("<h3>Your provided Credit card information is not sufficiant or wrong</h3>" +
                    "<p><i>This page automatically resets.</i>" +
                    "</body></html>");

            }
           out.close();
    }

    public String getServletInfo() {
        return "The Receipt servlet clears the shopping cart, " +
               "thanks the user for the order, and resets the " +
               "page to the BookStore's main page.";
    }
}

